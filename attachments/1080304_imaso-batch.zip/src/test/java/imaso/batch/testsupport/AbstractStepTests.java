package imaso.batch.testsupport;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.SimpleJob;



public abstract class  AbstractStepTests extends AbstractJobTests{
	
	abstract protected String getStepBeanId();
	
	@Override	
	protected Job getJob() {
		SimpleJob job =  new SimpleJob();
		job.setJobRepository(jobRepository);		
		job.setName(getJobBeanId());
		Step step = getStep();
		List<Step> steps = new ArrayList<Step>();
		steps.add(step);
		job.setSteps(steps);
		return job;
	}

	protected Step getStep() {
		Step step = (Step) applicationContext.getBean(getStepBeanId());
		return step;
	}
	
	protected String getJobBeanId(){
		return "testJob:"+getStepBeanId();
	}

}
