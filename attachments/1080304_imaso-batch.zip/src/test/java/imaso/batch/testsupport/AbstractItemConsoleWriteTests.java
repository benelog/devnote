package imaso.batch.testsupport;


import org.springframework.batch.core.Step;
import org.springframework.batch.core.step.item.SimpleStepFactoryBean;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.transaction.PlatformTransactionManager;

public abstract class AbstractItemConsoleWriteTests extends AbstractStepTests{
	
	abstract protected String getReaderBeanId();
	
	@Override		
	protected Step getStep() {
		SimpleStepFactoryBean factory = new  SimpleStepFactoryBean();
		ItemReader itemReader = getItemReader();
		setStreams(factory);
		factory.setItemReader(itemReader);
		factory.setItemWriter(new ConsoleItemWriter());
		PlatformTransactionManager txManager = (PlatformTransactionManager)applicationContext.getBean("transactionManager");
		factory.setTransactionManager(txManager);
		factory.setJobRepository(jobRepository);
		factory.setBeanName(getStepBeanId());
		Step step;
		try {
			step = (Step) factory.getObject();
		} catch (Exception e) {
			throw new IllegalStateException("print item failed.",e);
		}
		return step;
	}

	private void setStreams(SimpleStepFactoryBean factory) {
		String[] itemStreamBeanIds = getStreamBeanIds();
		ItemStream[] streams = new ItemStream[itemStreamBeanIds.length];
		for(int i=0,n=itemStreamBeanIds.length;i<n;i++){
			streams[i] = (ItemStream)applicationContext.getBean(itemStreamBeanIds[i]);
		}
		factory.setStreams(streams);
	}

	protected abstract String[] getStreamBeanIds();
	protected ItemReader getItemReader() {
		ItemReader itemReader = (ItemReader)applicationContext.getBean(getReaderBeanId());
		return itemReader;
	}
	
	protected String getStepBeanId(){
		return "testConsoleOutJob:"+getReaderBeanId();
	}
}
