package imaso.batch.testsupport;

import org.springframework.batch.item.support.DelegatingItemReader;

public class LimitedItemReader extends DelegatingItemReader {
	private int count;
	private int limit;

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public Object read() throws Exception {
		Object item = super.read();
		if(item != null)count++;
		if(isContinuable()) return item;
		else return null;
	}

	private boolean isContinuable() {
		return (limit>0) && (count<=limit);
	}
}
