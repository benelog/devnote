package imaso.batch.testsupport;

import java.util.Date;
import java.util.Properties;

import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.converter.DefaultJobParametersConverter;
import org.springframework.batch.core.converter.JobParametersConverter;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.repeat.ExitStatus;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public abstract class AbstractJobTests extends AbstractDependencyInjectionSpringContextTests {
	
	abstract protected String getJobBeanId();
	
	protected JobLauncher jobLauncher = null;
	protected JobRepository jobRepository = null;		

	protected JobParameters getJobParameters(){
		Properties prop = new Properties();
		String date = DateFormatUtils.format(new Date(), "yyyyMMddHHmmSSS");
		prop.setProperty("runTime", date);
		System.out.println(date+"!!!!!!");
		JobParametersConverter converter = new DefaultJobParametersConverter();
		return converter.getJobParameters(prop);
	}

	public void testLaunchJob() throws Exception {
		Job job = getJob();
		JobParameters jobParameters = getJobParameters();
		JobExecution execution = jobLauncher.run(job, jobParameters);
		System.out.println("job started at : " + execution.getStartTime());
		System.out.println("job ended at : " + execution.getEndTime());
		ExitStatus status = execution.getExitStatus();
		assertEquals(ExitStatus.FINISHED,status);
	}

	protected Job getJob() {
		Job job = (Job)applicationContext.getBean(getJobBeanId());
		return job;
	}

	public void setJobLauncher(JobLauncher jobLauncher) {
		this.jobLauncher = jobLauncher;
	}

	public void setJobRepository(JobRepository jobRepository) {
		this.jobRepository = jobRepository;
	}

	
}
