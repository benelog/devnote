package imaso.batch.testsupport;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public abstract class AbstractItemReaderTests extends AbstractDependencyInjectionSpringContextTests {
	
	abstract protected String getReaderBeanId();
	
	protected boolean isContinuable(long total){
		return true;
	}
	
	public void testLaunchJob() throws Exception {
		ItemReader reader = (ItemReader)applicationContext.getBean(getReaderBeanId());
		ExecutionContext context = new ExecutionContext();
		
	    if(reader instanceof ItemStream) ((ItemStream)reader).open(context);
	    Object item = null;
	    long total = 0;
		while( (item = reader.read())!= null && (isContinuable(total)) ) {
			System.out.println(item);	
			total++;
		}
		System.out.println("total read:" +total);
		if(reader instanceof ItemStream) ((ItemStream)reader).close(context);
	}
}
