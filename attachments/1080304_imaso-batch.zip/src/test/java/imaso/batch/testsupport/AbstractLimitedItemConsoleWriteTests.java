package imaso.batch.testsupport;


import org.springframework.batch.item.ItemReader;

public abstract class AbstractLimitedItemConsoleWriteTests extends
		AbstractItemConsoleWriteTests {

	abstract protected int getLimit();
	
	@Override
	protected ItemReader getItemReader() {
		ItemReader itemReader = super.getItemReader();
		LimitedItemReader limitedItemReader = new LimitedItemReader();
		limitedItemReader.setLimit(getLimit());
		limitedItemReader.setItemReader(itemReader);
		return limitedItemReader;
	}
}
