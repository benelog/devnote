package imaso.batch.testsupport;

import org.springframework.batch.item.support.AbstractItemWriter;

public class ConsoleItemWriter extends AbstractItemWriter {
	public void write(Object item) throws Exception {
		System.out.println(item);
	}
}
