package imaso.batch;

import imaso.batch.testsupport.AbstractStepTests;

public class TeamDbToXmlStepTestTemp extends AbstractStepTests {

	protected String[] getConfigLocations() {
		return new String[] {"simple-job-launcher-context.xml", "jobs/teamDbToXmlJob.xml" };
	}

	@Override
	protected String getStepBeanId() {
		return "teamDbToXmlStep";
	}
}

