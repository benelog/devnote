package imaso.batch;

import org.springframework.batch.core.JobParameters;

import imaso.batch.testsupport.AbstractJobTests;


public class TeamDbToXmlJobTest extends AbstractJobTests{

	protected String[] getConfigLocations() {
		return new String[] { "simple-job-launcher-context.xml",
				"jobs/teamDbToXmlJob.xml" };
	}
	
	@Override
	protected String getJobBeanId() {
		return "teamDbToXmlJob";
	}

	@Override
	protected JobParameters getJobParameters() {
		return new JobParameters();
	}
}
