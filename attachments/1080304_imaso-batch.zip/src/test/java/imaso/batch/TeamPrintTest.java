package imaso.batch;

import imaso.batch.testsupport.AbstractItemConsoleWriteTests;

public class TeamPrintTest extends AbstractItemConsoleWriteTests{


	protected String[] getConfigLocations() {
		return new String[] { "simple-job-launcher-context.xml",
				"jobs/teamDbToXmlJob.xml" };
	}
		
	@Override
	protected String getReaderBeanId() {
		return "teamReader";
	}

	@Override
	protected String[] getStreamBeanIds() {
		return new String[] {"teamMasterReader"};
	}

}
