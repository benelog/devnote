package imaso.batch.item.support;

import com.thoughtworks.xstream.io.xml.XmlFriendlyReplacer;

public class DummyReplacer extends XmlFriendlyReplacer {
	
	public String escapeName(String name) {
		return name;
	}

	public String unescapeName(String name) {
		return name;	
	}
}
