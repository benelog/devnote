package imaso.batch.item;

import imaso.batch.domain.Player;
import imaso.batch.domain.Team;
import imaso.batch.item.support.ItemWithChildrenReader;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class TeamReader extends ItemWithChildrenReader {

	private RowMapper mapper;
	private JdbcTemplate jdbcTemplate;
	private String sql;

	protected void setChildren(Object item) {
		Team team = (Team)item;
		Object[] params = new Object[]{team.getTeamId()};
		@SuppressWarnings("unchecked")
		List<Player> playerList = jdbcTemplate.query(sql, params, mapper);
		team.setPlayerList(playerList);
	}

	public void setMapper(RowMapper mapper) {
		this.mapper = mapper;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public String getSql() {
		return sql;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}



}
