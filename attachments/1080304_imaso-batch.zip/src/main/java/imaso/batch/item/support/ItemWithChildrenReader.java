package imaso.batch.item.support;

import org.springframework.batch.item.support.DelegatingItemReader;

public abstract class ItemWithChildrenReader extends DelegatingItemReader{
	
	public Object read() throws Exception {
		Object item = super.read();
		if(item==null) return null;
		setChildren(item);
		return item;
	}
	
	protected abstract void setChildren(Object item); 
	
	public ItemWithChildrenReader() {}

}
