package imaso.batch.item.support;

import org.springframework.oxm.XmlMappingException;
import org.springframework.oxm.xstream.AnnotationXStreamMarshaller;
import org.xml.sax.ContentHandler;
import org.xml.sax.ext.LexicalHandler;

import com.thoughtworks.xstream.io.xml.SaxWriter;
import com.thoughtworks.xstream.io.xml.XmlFriendlyReplacer;

public class ExtendedXStreamMarshaller extends AnnotationXStreamMarshaller{
	
	private XmlFriendlyReplacer replacer;
	
	public void setReplacer(XmlFriendlyReplacer replacer) {
		this.replacer = replacer;
	}

	protected void marshalSaxHandlers(Object graph,
			ContentHandler contentHandler, LexicalHandler lexicalHandler)
			throws XmlMappingException {
		SaxWriter saxWriter = new SaxWriter(replacer);
		saxWriter.setContentHandler(contentHandler);
		getXStream().marshal(graph, saxWriter);
	}

}
