package imaso.batch.domain;

import imaso.batch.domain.support.SinglePropertyObject;

public class ContentsSubject extends SinglePropertyObject{

	public ContentsSubject(String value) {
		super(value);
	}
}
