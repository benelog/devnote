package imaso.batch.domain;

import imaso.batch.domain.support.SinglePropertyObject;

import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;

public class ModifiedTime  extends SinglePropertyObject{

	public ModifiedTime(String value) {
		super(value);
	}
	
	public ModifiedTime() {
		super(DateFormatUtils.format(new Date(), "yyyyMMddHHmmss"));	
	}
}
