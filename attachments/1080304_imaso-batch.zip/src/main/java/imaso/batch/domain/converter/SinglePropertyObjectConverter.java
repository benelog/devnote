package imaso.batch.domain.converter;

import imaso.batch.domain.support.SinglePropertyObject;

import com.thoughtworks.xstream.converters.SingleValueConverter;

public class SinglePropertyObjectConverter implements SingleValueConverter {

    @SuppressWarnings("unchecked")
	public boolean canConvert(Class type) {
        return SinglePropertyObject.class.isAssignableFrom(type);
    }

	public Object fromString(String s) {
    	return new SinglePropertyObject(s);
	}

	public String toString(Object obj) {
		return obj.toString();
	}
}
