package imaso.batch.domain.support;

public class SinglePropertyObject {
	
	private String value;
	public SinglePropertyObject(String value){
		this.value=value;
	}
	
	public String toString(){
		return value;
	}
}
