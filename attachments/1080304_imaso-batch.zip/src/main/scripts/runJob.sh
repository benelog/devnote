#!/bin/sh
BASEDIR=`dirname $0`
cd $BASEDIR

CLASSPATH=$BASEDIR
CLASSPATH=$CLASSPATH:$BASEDIR/imaso-batch.jar

for f in `find $BASEDIR/lib -type f -name "*.jar"`
do
   CLASSPATH=$CLASSPATH:$f
done

JAVA_BIN=$JAVA_HOME/bin/java
OPT="-cp $CLASSPATH -Xmx512M"

# ***************
# ** Run...    **
# ***************
echo $JAVA_BIN
$JAVA_BIN $OPT org.springframework.batch.core.launch.support.CommandLineJobRunner 
