@echo off
set JAVA_CMD=%JAVA_HOME%\bin\java
set MAIN_CLASS=org.springframework.batch.core.launch.support.CommandLineJobRunner
set CLASSPATH=.
FOR %%F IN (*.jar) DO call :addcp %%F

REM **********************
REM   External Libraries
REM **********************
FOR %%F IN (lib\*.jar) DO call :addcp %%F
goto extlibe

:addcp
set CLASSPATH=%CLASSPATH%;%1
goto :eof

:extlibe

"%JAVA_CMD%" -Xmx512M -cp "%CLASSPATH%" %MAIN_CLASS% %*
