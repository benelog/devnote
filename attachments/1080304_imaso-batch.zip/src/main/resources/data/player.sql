CREATE TABLE PLAYER
(
  team_id INTEGER
, player_id INTEGER
, player_name VARCHAR(20)
, main_position VARCHAR(20)
)
;


INSERT INTO PLAYER(team_id, player_id, player_name, main_position) VALUES ( 1, 1,'이대호','3루수');
INSERT INTO PLAYER(team_id, player_id, player_name, main_position) VALUES ( 1, 2,'강민호','포수');
INSERT INTO PLAYER(team_id, player_id, player_name, main_position) VALUES ( 2, 3,'배영수','투수');
INSERT INTO PLAYER(team_id, player_id, player_name, main_position) VALUES ( 2, 4,'오승환','투수');