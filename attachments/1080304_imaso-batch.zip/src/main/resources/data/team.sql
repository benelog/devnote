CREATE TABLE TEAM
(
  team_id INTEGER
, team_name VARCHAR(20)
, symbol VARCHAR(20)
, rank INTEGER
)
;

INSERT INTO TEAM(team_id, team_name, symbol, rank) VALUES ( 1,'Lotte','Giants', 1);
INSERT INTO TEAM(team_id, team_name, symbol, rank) VALUES ( 2,'Samsung','Lions', 2);