package proxy.sample1.emp;

public interface EmpManager
{
    public void printGreetingMessage(String message) throws Exception;
}
