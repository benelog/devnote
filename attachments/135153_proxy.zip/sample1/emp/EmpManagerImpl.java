package proxy.sample1.emp;

public class EmpManagerImpl implements EmpManager
{
    public void printGreetingMessage(String message) throws Exception
    {
        System.out.println( "Hi: " + message);
        throw new Exception("�Ϻη� ���� ���� ");
    }
}
