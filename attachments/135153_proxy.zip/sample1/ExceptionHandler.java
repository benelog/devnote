package proxy.sample1;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class ExceptionHandler implements InvocationHandler
{
    Object targetObject;

    public ExceptionHandler(Object targetObject)
    {
        this.targetObject = targetObject;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
    {
        try
        {
            return method.invoke(targetObject, args);
        }
        catch (Throwable e)
        {
            System.out.println("----------------------------------");
            System.out.println("�޼ҵ� ȣ��  ���ܹ߻�:[" + method + "], ���� �޼���[" + e.getMessage() + "]");
            System.out.println("----------------------------------");
            return null;
        }
    }
}
