package proxy.sample1;

import java.lang.reflect.Proxy;

import proxy.sample1.ExceptionHandler;
import proxy.sample1.LoggingHandler;
import proxy.sample1.emp.EmpManager;
import proxy.sample1.emp.EmpManagerImpl;

public class ProxyTest
{

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception
    {
        EmpManager managerProxy = getServerObject(); //���� ��ü�� ���´�. 
        managerProxy.printGreetingMessage("This is test");
    }

    /**
     * @return
     */
    private static EmpManager getServerObject() {
        ExceptionHandler exceptionHandler = new ExceptionHandler(new EmpManagerImpl());

        LoggingHandler logHandler = new LoggingHandler(Proxy.newProxyInstance(EmpManager.class.getClassLoader(),
                new Class[] { EmpManager.class }, exceptionHandler));

        EmpManager managerProxy = (EmpManager) Proxy.newProxyInstance(EmpManager.class.getClassLoader(),
                new Class[] { EmpManager.class }, logHandler);
        return managerProxy;
    }
}
