package proxy.sample1;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class LoggingHandler implements InvocationHandler
{
    Object targetObject;

    public LoggingHandler(Object targetObject)
    {
        this.targetObject = targetObject;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
    {
        try
        {
            System.out.println("----------------------------------");
            System.out.println("�޼ҵ� ȣ�� Start:[" + method + "][" + System.currentTimeMillis() + "]");
            return method.invoke(targetObject, args);
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            System.out.println("�޼ҵ� ȣ�� End:[" + method + "][" + System.currentTimeMillis() + "]");
            System.out.println("----------------------------------");
        }
    }
}
